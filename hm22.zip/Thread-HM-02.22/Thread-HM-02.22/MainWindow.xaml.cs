﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Thread_HM_02._22
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static Random rnd = new Random();
        ObservableCollection<int> objCollT1 = new ObservableCollection<int>();
        ObservableCollection<char> objCollT2 = new ObservableCollection<char>();
        ObservableCollection<char> objCollT3 = new ObservableCollection<char>();
        private void RandNumb(object obj )
        {
           
             for (int i = 0; i < 5; ++i)
             { 
               Application.Current.Dispatcher.Invoke(new Action(() =>
               {
                   int numb = rnd.Next(100,200); 
                   objCollT1.Add(numb);

               }));
               Thread.Sleep(1000);

             }

            
        }
        private void RandLeters(object obj)
        {
            for(int i = 0;i<5;++i){ 
            Application.Current.Dispatcher.Invoke(() =>
            {
               
               objCollT2.Add((char)rnd.Next('A', 'Z'));
               
            });
            Thread.Sleep(1000);
            }

        }
        private void RandSymb(object obj)
        {
            for (int i = 0; i < 5; ++i)
            {
                Application.Current.Dispatcher.Invoke(() =>
                {

                    objCollT3.Add((char)rnd.Next(33, 48));

                });
                Thread.Sleep(1000);
            }

        }

        public MainWindow()
        {
            InitializeComponent();
            listBox.ItemsSource = objCollT1;
            listBox1.ItemsSource = objCollT2;
            listBox2.ItemsSource = objCollT3;

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Thread numb = new Thread(RandNumb);
            numb.Priority = ThreadPriority.Normal;
            numb.Start();
            Thread leter = new Thread(RandLeters);
            leter.Priority = ThreadPriority.Lowest;
            leter.Start();
            Thread symb = new Thread(RandSymb);
            symb.Priority = ThreadPriority.Highest;
            symb.Start();

        }
    }
}
