﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Forms;
using System.Threading;

namespace Task_2
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // нада великий файл шоб прогрес бар гарно показував

        public FileCopyInfo fileCopyInfo = new FileCopyInfo();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            Microsoft.Win32.OpenFileDialog dialog = new Microsoft.Win32.OpenFileDialog();
            dialog.ShowDialog();
            fileCopyInfo = new FileCopyInfo() { From = new FileInfo(dialog.FileName), FileName = dialog.SafeFileName };
            tbFrom.Text = dialog.FileName;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.ShowDialog();
            tbTo.Text = dialog.SelectedPath;

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            if (fileCopyInfo.Thread == null)
            {
                fileCopyInfo.To = new FileInfo(tbTo.Text + "\\" + fileCopyInfo.FileName);
                fileCopyInfo.Thread = new Thread(() =>
                {
                    FileCopy.CopyTo(fileCopyInfo, (x => Dispatcher.Invoke(() => fileCopyInfo.Progress = x)));
                });
                fileCopyInfo.Thread.Start();
                System.Windows.Data.Binding binding = new System.Windows.Data.Binding
                {
                    Source = fileCopyInfo,
                    Path = new PropertyPath("Progress"),
                };
                progress.SetBinding(System.Windows.Controls.ProgressBar.ValueProperty, binding);
            }
            else
            {
                fileCopyInfo.Thread.Resume();
            }

        }
        /// <summary>
        /// 3 tasks
       
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            fileCopyInfo.Thread.Abort();
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            fileCopyInfo.Thread.Suspend();
        }
    }
}
