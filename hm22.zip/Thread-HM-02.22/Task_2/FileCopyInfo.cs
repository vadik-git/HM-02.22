﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Task_2
{
    public class FileCopyInfo : INotifyPropertyChanged
    {
        public Thread Thread;
        public string FileName { get; set; }
        public FileInfo From { get; set; }
        public FileInfo To { get; set; }
        private float progress;
        public float Progress
        {
            get { return progress; }
            set
            {
                progress = value;
                OnPropertyChanged();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

    }
    static class FileCopy
    {

        public static void CopyTo(FileCopyInfo fileCopyInfo, Action<int> progressCallback)
        {
            const int bufferSize = 1024 * 1024;  
            byte[] buffer = new byte[bufferSize], buffer2 = new byte[bufferSize];
            bool swap = false;
            int progress = 0, reportedProgress = 0, read = 0;
            long len = fileCopyInfo.From.Length;
            float flen = len;
            Task writer = null;
            using (var source = fileCopyInfo.From.OpenRead())
            using (var dest = fileCopyInfo.To.OpenWrite())
            {
                dest.SetLength(source.Length);
                for (long size = 0; size < len; size += read)
                {
                    if ((progress = ((int)((size / flen) * 100))) != reportedProgress)
                        progressCallback(reportedProgress = progress);
                    read = source.Read(swap ? buffer : buffer2, 0, bufferSize);
                    writer?.Wait();  
                    writer = dest.WriteAsync(swap ? buffer : buffer2, 0, read);
                    swap = !swap;
                }
                writer?.Wait();  
            }
            progressCallback(100);
        }
    
}
}
