﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Task8
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Count()
        {
            Application.Current.Dispatcher.Invoke(new Action(() =>
            {
                string text = tbText.Text;


                int upper = Regex.Matches(text, @"[аоуеиі]", RegexOptions.IgnoreCase).Count;
                int nonUpper = Convert.ToInt32(text.Length)-upper;
               /* for (int i = 0; i < text.Length; i++)
                {
                    if (char.IsUpper(text[i]))
                    {
                        upper++ ;
                    }
                    else
                    {
                        ++nonUpper;
                    }
                }*/
                MessageBox.Show($"Upper {upper} not upper {nonUpper}");
            }));
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Thread task = new Thread(Count);
            task.Start();
        }
    }
}
